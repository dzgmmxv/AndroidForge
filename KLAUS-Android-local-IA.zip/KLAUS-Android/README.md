# KLAUS Android — prototip 0.2 (IA local)

Aquest projecte és una base tècnica Android en Kotlin + Jetpack Compose. Integra LiteRT-LM per executar un model `.litertlm` directament al dispositiu, dictat amb el servei de veu d'Android i lectura de respostes amb TextToSpeech.

## Privacitat i connexió
- Les inferències del model local es fan al telèfon; no hi ha cap endpoint de núvol ni clau d'API.
- L'app no declara permís d'Internet.
- El fitxer del model es copia a l'emmagatzematge privat de l'app.
- El dictat i la síntesi de veu depenen de les funcions de veu instal·lades al telèfon; segons el proveïdor, el reconeixement de veu pot requerir serveis externs. Per a privacitat màxima, configura reconeixement fora de línia al sistema i comprova que el paquet de català està instal·lat.

## Requisits
- Android Studio recent.
- JDK 17 o la versió recomanada per Android Studio.
- Mòbil Android amb espai lliure suficient i, idealment, 6–8 GB de RAM per provar un model petit. El rendiment real depèn del dispositiu.
- Connexió a Internet només per obtenir el model i les dependències de desenvolupament; l'app no necessita connexió per inferir una vegada carregat el model.

## Compilar
1. Descomprimeix el ZIP.
2. Obre la carpeta `KLAUS-Android` a Android Studio.
3. Permet la sincronització de Gradle i descarrega les dependències.
4. Connecta el mòbil per USB amb depuració USB activada o utilitza un emulador compatible.
5. Prem Run per instal·lar la versió de depuració.

## Afegir un model
1. Obté un model `.litertlm` compatible amb LiteRT-LM. Consulta el catàleg oficial: https://huggingface.co/litert-community
2. Comprova la targeta del model, la llicència, la mida i les necessitats de memòria. Per començar, busca un model instruct petit (aprox. 1B–2B paràmetres, quantitzat si n'hi ha una variant compatible).
3. Copia el fitxer al telèfon (per exemple, a Descàrregues).
4. Obre KLAUS i toca la icona de carpeta a la part superior. Selecciona el fitxer `.litertlm`.
5. Espera que acabi la càrrega; la primera inicialització pot trigar uns segons i consumir força RAM.

## Important
- No s'inclou cap model dins el ZIP: aquests fitxers poden ocupar centenars de MB o diversos GB i les llicències varien.
- El projecte encara és un prototip. No s'ha compilat ni provat en el mòbil de l'usuari en aquest entorn.
- L'historial de xat només es conserva mentre l'app està oberta; la persistència local i la gestió de models es milloraran en una següent iteració.
- El backend CPU s'utilitza com a opció de compatibilitat inicial. L'acceleració GPU es pot activar després de validar compatibilitat al dispositiu.
- LiteRT-LM recomana l'API Kotlin per a aplicacions noves; la documentació oficial és https://github.com/google-ai-edge/LiteRT-LM/blob/main/docs/api/kotlin/getting_started.md
