package com.klaus.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

private val Ink = Color(0xFF090D12)
private val Panel = Color(0xFF121A23)
private val Cyan = Color(0xFF64D8FF)
private val TextMain = Color(0xFFEAF4FA)
private val TextMuted = Color(0xFF91A4B3)

data class ChatMessage(val text: String, val fromKlaus: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val catalan = tts?.setLanguage(Locale("ca", "ES"))
                if (catalan == TextToSpeech.LANG_MISSING_DATA ||
                    catalan == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale("es", "ES"))
                }
        } }
        setContent {
            KlausApp(
                speak = { message -> tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "klaus_reply") }
            )
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KlausApp(speak: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Hola! Soc en Klaus. Quan carreguis un model local, podré conversar sense enviar els teus missatges a un servidor.", true)
        )
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var speakReplies by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("Cap model carregat") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var engine by remember { mutableStateOf<Engine?>(null) }
    var conversation by remember { mutableStateOf<Conversation?>(null) }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!matches.isNullOrEmpty()) input = matches.first()
        else errorText = "No he pogut entendre el dictat. Torna-ho a provar."
    }
    val modelPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                errorText = null
                status = "Copiant el model al telèfon…"
                try {
                    val modelFile = withContext(Dispatchers.IO) {
                        val target = File(context.filesDir, "klaus-model.litertlm")
                        context.contentResolver.openInputStream(uri).use { source ->
                            requireNotNull(source) { "No s'ha pogut obrir el fitxer seleccionat." }
                            target.outputStream().use { dest -> source.copyTo(dest) }
                        }
                        target
                    }
                    status = "Carregant el model local…"
                    val loaded = withContext(Dispatchers.IO) {
                        val newEngine = Engine(
                            EngineConfig(
                                modelPath = modelFile.absolutePath,
                                backend = Backend.CPU(),
                                cacheDir = context.cacheDir.absolutePath
                            )
                        )
                        newEngine.initialize()
                        newEngine
                    }
                    withContext(Dispatchers.IO) {
                        conversation?.close()
                        engine?.close()
                    }
                    engine = loaded
                    conversation = withContext(Dispatchers.IO) {
                        loaded.createConversation(
                            ConversationConfig(
                                systemInstruction = Contents.of(
                                    "Ets KLAUS, un assistent personal útil, honest i respectuós. " +
                                    "Respon en català si l'usuari parla català i en castellà si parla castellà. " +
                                    "Sigues clar, pràctic i no inventis informació."
                                )
                            )
                        )
                    }
                    status = "Model local carregat · mode sense núvol"
                    messages.add(ChatMessage("Model carregat correctament. Ja podem conversar localment.", true))
                } catch (e: Exception) {
                    status = "No s'ha pogut carregar el model"
                    errorText = "Error carregant el model: ${e.message ?: "format no compatible"}"
                } finally {
                    busy = false
                }
            }
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ca-ES")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Parla amb Klaus")
                }
                speechLauncher.launch(intent)
            } else errorText = "No hi ha cap servei de reconeixement de veu disponible."
        } else errorText = "Cal permís del micròfon per dictar missatges."
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Ink, surface = Panel,
            onBackground = TextMain, onSurface = TextMain
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(40.dp).background(Color(0xFF173044), CircleShape),
                                contentAlignment = Alignment.Center) {
                                Text("K", color = Cyan, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("KLAUS", fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Text(status, fontSize = 10.sp, color = TextMuted)
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { speakReplies = !speakReplies }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Activar o desactivar veu",
                                tint = if (speakReplies) Cyan else TextMuted)
                        }
                        IconButton(onClick = { modelPicker.launch(arrayOf("*/*")) }) {
                            Icon(Icons.Default.FolderOpen, contentDescription = "Carregar model local", tint = Cyan)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Row(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(26.dp))
                            .padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BasicTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                            textStyle = TextStyle(color = TextMain, fontSize = 16.sp),
                            cursorBrush = SolidColor(Cyan),
                            decorationBox = { inner ->
                                Box {
                                    if (input.isEmpty()) Text("Escriu a Klaus...", color = TextMuted)
                                    inner()
                                }
                            }
                        )
                        IconButton(onClick = {
                            if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                if (SpeechRecognizer.isRecognitionAvailable(context)) {
                                    speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ca-ES")
                                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Parla amb Klaus")
                                    })
                                } else errorText = "No hi ha cap servei de reconeixement de veu disponible."
                            } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }) { Icon(Icons.Default.Mic, contentDescription = "Dictar", tint = Cyan) }
                        IconButton(
                            enabled = input.isNotBlank() && !busy,
                            onClick = {
                                val prompt = input.trim()
                                if (prompt.isNotEmpty()) {
                                    messages.add(ChatMessage(prompt, false))
                                    input = ""
                                    val activeConversation = conversation
                                    if (activeConversation == null) {
                                        messages.add(ChatMessage("Carrega primer un model .litertlm amb la icona de carpeta.", true))
                                    } else {
                                        busy = true
                                        errorText = null
                                        scope.launch {
                                            try {
                                                val reply = withContext(Dispatchers.IO) {
                                                    val output = StringBuilder()
                                                    activeConversation.sendMessageAsync(prompt).collect { chunk ->
                                                        output.append(chunk.toString())
                                                    }
                                                    output.toString().ifBlank { "No he generat cap resposta." }
                                                }
                                                messages.add(ChatMessage(reply, true))
                                                if (speakReplies) speak(reply)
                                            } catch (e: Exception) {
                                                errorText = "Error generant resposta: ${e.message ?: "error desconegut"}"
                                            } finally {
                                                busy = false
                                            }
                                        }
                                    }
                                }
                            }
                        ) { Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Cyan) }
                    }
                    Text("Les respostes d'IA es processen al dispositiu. El dictat pot dependre del servei de veu instal·lat.",
                        Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp),
                        color = TextMuted, fontSize = 10.sp)
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(Modifier.height(8.dp))
                            Box(Modifier.size(76.dp).background(Color(0xFF112B3B), CircleShape),
                                contentAlignment = Alignment.Center) {
                                Text("K", color = Cyan, fontSize = 42.sp, fontWeight = FontWeight.Light)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("Sempre a punt.", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                            Text("IA local · conversa privada", color = TextMuted, fontSize = 13.sp)
                        }
                    }
                    items(messages) { message ->
                        Row(Modifier.fillMaxWidth(),
                            horizontalArrangement = if (message.fromKlaus) Arrangement.Start else Arrangement.End) {
                            Column(
                                Modifier.widthIn(max = 310.dp)
                                    .background(if (message.fromKlaus) Panel else Color(0xFF173044), RoundedCornerShape(18.dp))
                                    .padding(horizontal = 15.dp, vertical = 12.dp)
                            ) {
                                if (message.fromKlaus) Text("KLAUS", color = Cyan, fontSize = 10.sp, letterSpacing = 1.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(message.text, color = TextMain, fontSize = 15.sp, lineHeight = 21.sp)
                            }
                        }
                    }
                    if (busy) item { Text("Klaus està treballant…", color = Cyan, modifier = Modifier.padding(start = 8.dp)) }
                    errorText?.let { err -> item { Text(err, color = Color(0xFFFF9A9A)) } }
                }
            }
        }
    }
}
