# Guia de compilació de KLAUS per a OPPO Reno14 5G

## Model per a la primera prova
Comença amb `Qwen3-0.6B.litertlm` del repositori:
https://huggingface.co/litert-community/Qwen3-0.6B

No triïs fitxers amb sufixos `-web` ni builds NPU específics del xip. Selecciona el fitxer `.litertlm` estàndard que la targeta del model indica per a CPU/GPU. La mida, la quantització i el context varien segons el fitxer.

Model alternatiu més gran:
https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm

## A. Preparar l'ordinador
1. Instal·la Android Studio recent: https://developer.android.com/studio
2. Durant la instal·lació, inclou Android SDK i Android SDK Platform 36 si Android Studio ho ofereix.
3. Obre Android Studio i selecciona **Open**.
4. Tria la carpeta arrel `KLAUS-Android` (la que conté `settings.gradle.kts`).
5. Accepta la sincronització de Gradle. Necessitaràs internet per descarregar les dependències de compilació.
6. Si Android Studio demana instal·lar una versió del JDK, accepta la versió recomanada per l'IDE.

## B. Compilar l'APK de depuració
Des d'Android Studio:
1. Espera que finalitzi **Gradle Sync**.
2. Selecciona **Build > Make Project**.
3. Si la compilació acaba correctament, selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. L'APK de depuració habitualment queda a:
   `app/build/outputs/apk/debug/app-debug.apk`

També pots obrir un terminal a la carpeta del projecte i executar:
- Windows: `gradlew.bat assembleDebug`
- macOS/Linux: `./gradlew assembleDebug`

Si el projecte no inclou `gradlew` i la carpeta `gradle/wrapper/gradle-wrapper.jar`, obre'l primer amb Android Studio perquè puguis generar/instal·lar el wrapper, o utilitza Gradle des de l'IDE. No executis scripts desconeguts si no has revisat el seu contingut.

## C. Instal·lar al mòbil
1. Al telèfon, activa Opcions de desenvolupador i Depuració USB.
2. Connecta'l per USB i accepta l'avís de depuració.
3. A Android Studio, selecciona el telèfon com a dispositiu i prem **Run**.
4. Alternativament, transfereix `app-debug.apk` al telèfon i obre'l. Android pot demanar que autoritzis la instal·lació des d'aquesta font.

## D. Carregar el model
1. Descarrega el fitxer `.litertlm` compatible des de Hugging Face a l'ordinador.
2. Copia'l a Descàrregues del telèfon per USB.
3. Obre KLAUS i toca la icona de carpeta de la barra superior.
4. Selecciona el fitxer de model. L'app el copiarà a l'emmagatzematge privat i intentarà inicialitzar-lo.
5. La primera càrrega pot tardar. Deixa espai lliure suficient i tanca altres aplicacions si cal.

## E. Prova bàsica
Prova primer missatges curts:
- `Hola, Klaus. Respon en català.`
- `Fes una llista de cinc tasques per avui.`
- `Resumeix en tres frases què és una IA local.`

Després activa la lectura en veu alta i prova el dictat. El dictat d'Android pot requerir un paquet de reconeixement de veu; per a un ús completament fora de línia, configura al sistema un servei i un paquet de català que admetin reconeixement sense connexió.

## Problemes habituals
- **Gradle Sync falla:** comprova que l'ordinador té internet i que Android Studio ha instal·lat SDK/JDK compatibles.
- **El model no carrega:** assegura't que és un fitxer `.litertlm` estàndard compatible, no un model `.gguf`, `.tflite` o una build `-web`/NPU.
- **L'app es tanca o va molt lenta:** prova el model petit Qwen3-0.6B, reinicia el telèfon i deixa memòria lliure.
- **No hi ha resposta d'IA:** comprova que la barra superior indica que el model local està carregat.

## Limitacions conegudes
Aquest projecte és un prototip de codi font i encara no s'ha compilat ni validat físicament en un OPPO Reno14 5G. La integració de LiteRT-LM, les versions de Gradle/Kotlin i la selecció de model s'han de validar amb `assembleDebug` i una prova real. L'historial encara no es desa després de tancar l'app.
